import logging
from fastapi import HTTPException, Depends, APIRouter
from reddevil.core import RdException
from typing import List

from .md_filestore import FileIn
from .filestore import (
    get_file,
    public_url,
    mgmt_get_file_metadata,
    anon_list_files,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/filestore")


@router.get("/anon/file", response_model=str)
async def api_anon_get_file(group: str, name: str):
    try:
        return await get_file(group, name)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        logger.exception("failed api call anon_get_file")
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.get("/anon/public_url", response_model=str)
def api_anon_public_url(group: str, name: str):
    try:
        return public_url(group, name)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        logger.exception("failed api call anon_get_file")
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.get("/anon/files", response_model=List[str])
async def api_anon_get_file(group: str):
    try:
        return await anon_list_files(group)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        logger.exception("failed api call anon_get_file")
        raise HTTPException(status_code=500, detail="Internal Server Error")


@router.get("/mgmt/metadata")
async def api_mgmt_get_file(group: str, name: str):
    try:
        return await mgmt_get_file_metadata(group, name)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        logger.exception("failed api call anon_get_file")
        raise HTTPException(status_code=500, detail="Internal Server Error")
