# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2022

# all models in the service level exposed to the API
# we are using pydantic as tool

from ast import alias
from datetime import datetime, date, timezone
from typing import Dict, Any, List, Type, Tuple, Literal, TypeAlias
from enum import Enum
from pydantic import BaseModel
from reddevil.core.dbbase import DbBase


LoginType: TypeAlias = Literal["email", "google", "facebook"]


class Account_:
    """
    the account class as stored in the Mongodb database
    this is just for info, should never be used, as our own driver
    translates the "_id" field to an "id" field and takes care of the hidden fields
    """

    domain: str
    email: str
    enabled: bool
    hashed_password: str
    locale: str
    logintype: LoginType
    expiration_time: datetime
    tokensalt: str
    super: bool
    verified: bool
    _id: str
    _documenttype: str
    _version: int
    _creationtime: datetime
    _modificationtime: datetime


class AccountDB(BaseModel):
    """
    The account class:
     - after mongodb transformation of the _id
     - without the hashes_password
    """

    domain: str
    email: str
    enabled: bool = False
    expirationtime: datetime | None = None
    id: str
    locale: str = "en"
    logintype: LoginType = "email"
    super: bool = False
    tokensalt: str = "SamsonEnGert"
    verified: bool = False
    _creationtime: datetime
    _modificationtime: datetime
    _version: int = 1


class DbAccount(DbBase):
    COLLECTION = "rd_account"
    DOCUMENTTYPE = "Account"
    HIDDENFIELDS = ["hashed_password"]
    VERSION = 1


# account validators


class AccountInValidator(BaseModel):
    """
    validator to create a new account on API lvel
    """

    domain: str | None = ""
    email: str
    enabled: bool = True
    id: str
    logintype: LoginType
    password: str | None = ""
    verified: bool = True


class AccountOutValidator(BaseModel):
    """
    A standard validator for a account
    """

    domain: str
    email: str
    enabled: bool
    id: str
    locale: str | None
    logintype: LoginType
    verified: bool = False


class AccountOutDetailValidator(BaseModel):
    """
    validator for a detailed account
    """

    _creationtime: datetime
    domain: str = ""
    email: str
    enabled: bool = False
    expiration_time: datetime | None = None
    id: str
    locale: str
    logintype: LoginType
    _modificationtime: datetime
    verified: bool = False


class AccountUpdateValidator(BaseModel):
    """
    validator for an AccountUpdate
    """

    domain: str | None = None
    enabled: bool | None = None
    locale: str | None = None
    logintype: LoginType | None = None
    verified: bool | None = None


class AccountLoginValidator(BaseModel):
    """
    validator for logging in
    """

    logintype: LoginType
    password: str | None = None
    token: str | None = None
    username: str | None = None


class AccountPasswordUpdateValidator(BaseModel):
    """
    validator for passwordupdate
    """

    newpassword: str
    oldpassword: str
    username: str


class AccountPasswordResetValidator(BaseModel):
    """
    validator for passwordreset
    """

    username: str | None
    email: str | None
    locale: str


class AccountPasswordConfirmValidator(BaseModel):
    """
    validator for passwordconfirm
    """

    email: str
    newpassword: str
    username: str
    token: str
